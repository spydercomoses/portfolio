# Responsive Personal Portfolio


Technologies used in building this project
 HTML5, CSS3, JavaScript

View Personal Portfolio by [Oluwakemi](https://codepen.io/techgirldiaries) for freecodeCamp Challenge [here](https://tgd-portfolio.netlify.app/).
